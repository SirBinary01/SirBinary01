import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:tiktok/constants.dart';

class Loading extends StatelessWidget {
  final String text;
  Loading({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: Container(
        
          
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Padding(padding: EdgeInsets.all(10)),
              SpinKitWave(
                color: buttonColor,
                size: 50,
              ),
              SizedBox(height: 15,),
              Center(
                
                child:  Text(
                  text,
                  style: const TextStyle(
                  fontSize: 20,
                  color: Colors.redAccent,
                  fontWeight: FontWeight.w900,
                  decoration: TextDecoration.none,
                ),
              ),
              )
            ],
          ),
        
      ),
    );
  }
}
